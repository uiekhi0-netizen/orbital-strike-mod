@rem
@gradle build %*
